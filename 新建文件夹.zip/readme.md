


# 1. 分析 bag 文件数据
提取话题信息 使用以下命令列出 bag 文件的所有话题：

bash
复制代码
rosbag info jiantu2.bag
提取具体话题内容 通过 rostopic echo 查看具体话题数据：

bash
复制代码
rostopic echo /topic_name

# 基本信息
path: jiantu2.bag
Bag 文件的名称和路径。

version: 2.0
Bag 文件的格式版本。

duration: 1:43s (103s)
记录的时间总长为 1 分 43 秒（103 秒）。

start: Sep 21 2024 06:52:48.60 (1726872768.60)
记录的起始时间是 2024 年 9 月 21 日 06:52:48.60。括号内为 UNIX 时间戳。

end: Sep 21 2024 06:54:32.41 (1726872872.41)
记录的结束时间是 2024 年 9 月 21 日 06:54:32.41。括号内为 UNIX 时间戳。

size: 36.9 MB
Bag 文件的大小为 36.9 MB。

messages: 91348
Bag 文件中总共包含 91348 条消息。

compression: none [48/48 chunks]
数据未被压缩，分为 48 个块（chunk）。

# 消息类型
列出 Bag 文件中包含的消息类型及其 MD5 哈希，用于确认消息类型的定义：

nav_msgs/Odometry [cd5e73d190d741a2f92e81eda573aca7]
表示里程计数据，通常用于描述机器人在空间中的位置信息。

sensor_msgs/Imu [6a62c6daae103f4ff57a132d6f95cec2]
表示惯性测量单元（IMU）的数据，包括线性加速度和角速度。

sensor_msgs/LaserScan [90c7ef2dc6895d81024acba2ac42f369]
表示激光雷达扫描数据。

sensor_msgs/MagneticField [2f3b0b43eed0c9501de0fa3ff89a45aa]
表示磁场传感器的数据。

话题（Topics）
列出 Bag 文件中记录的 ROS 话题名称、消息数以及其消息类型：

/driver/encoder

消息数：4758
消息类型：nav_msgs/Odometry
包含机器人编码器的数据，用于位置估计。
/driver/eul

消息数：28635
消息类型：sensor_msgs/Imu
包含机器人惯性传感器的欧拉角数据。
/driver/imu

消息数：28469
消息类型：sensor_msgs/Imu
包含惯性测量单元（IMU）的数据。
/driver/mag

消息数：28469
消息类型：sensor_msgs/MagneticField
包含磁力计传感器的数据。
/driver/scan

消息数：1017
消息类型：sensor_msgs/LaserScan
包含激光雷达的扫描数据。


# 4运行步骤总结
启动 ROS master：
bash
复制代码
roscore
播放 bag 文件：
bash
复制代码
rosbag play jiantu2.bag
启动自定义节点（Python 或 C++）：
bash
复制代码
rosrun talker_listener talker_listener